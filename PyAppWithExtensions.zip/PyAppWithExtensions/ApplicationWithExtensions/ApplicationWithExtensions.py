import sys
from fast import fast_factorial, fast_tg, fast_concatenation

a = 9
b = 1
print(fast_factorial(a))
print(fast_tg(b))
print(fast_concatenation(["hello ", "world"]))
